<?php
$mysql = array();
$mysql['type'] = 'mysql'; 
$mysql['hostname'] = 'localhost'; 
$mysql['user'] = 'user'; 
$mysql['pass'] = 'pass'; 
$mysql['db'] = 'dbname'; 
?>
