<?php
$lang = array();
$lang['months'] = 'January,February,March,April,May,June,July,August,September,October,November,December'; 
$lang['year'] = 'Year'; 
$lang['states'] = 'RESERVED,OCCUPIED,FREE'; 
$lang['type'] = 'lang'; 
?>