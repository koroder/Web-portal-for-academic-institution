<?php
$conf = array();
$conf['type'] = 'conf'; 
$conf['login'] = 'admin'; 
$conf['password'] = 'admin'; 
$conf['copyright'] = 'Yes'; 
?>